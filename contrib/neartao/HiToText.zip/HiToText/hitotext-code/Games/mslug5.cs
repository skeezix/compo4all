﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using HiToText;
using HiToText.Utils;

namespace HiGames
{       
    class mslug5 : mslug3
    {
        // As mslug3, the character or mission byte is always 0x00 even in the default score,
        // no matter which character is selected or missions acomplished
        public mslug5()
        {
            m_numEntries = 10;
            m_format = "RANK|SCORE|NAME";
            m_gamesSupported = "mslug5,mslug5h,ms5plus,ms5pcb";
            m_extensionsRequired = ".nv";
        }  
    }
}