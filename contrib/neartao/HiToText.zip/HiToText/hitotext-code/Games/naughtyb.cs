using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using HiToText;
using HiToText.Utils;

namespace HiGames
{
    class naughtyb : phoenix
    {
        //TODO: Set Alternates.
        public naughtyb()
        {
            m_numEntries = 1;
            m_format = "SCORE";
            m_gamesSupported = "naughtyb,naughtyba,naughtybc,naughtya,naughtyc";
            m_extensionsRequired = ".hi";
        }       
    }
}

