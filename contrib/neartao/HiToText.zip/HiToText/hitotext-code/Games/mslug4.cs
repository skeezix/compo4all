﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using HiToText;
using HiToText.Utils;

namespace HiGames
{       
    class mslug4 : mslug3
    {
        // Even taken by default some values, it seems that the characer or mission byte 
        // is always set to 0x00 when you enter a new hiscore, so I really
        // don't know if this could be taken in count. For now, No.
        public mslug4()
        {
            m_numEntries = 10;
            m_format = "RANK|SCORE|NAME";
            m_gamesSupported = "mslug4,ms4plus";
            m_extensionsRequired = ".nv";
        }  
    }
}