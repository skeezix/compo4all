#!/usr/bin/env bash

mono HiToText.exe -l
