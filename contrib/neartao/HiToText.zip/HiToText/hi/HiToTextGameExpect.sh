#!/usr/bin/env expect

#As first thing we check to have 5 arguments:
if {[llength $argv] != 1} {

# We give a message so the user know our syntax:
puts "usage: HiToTextGame.sh <game>.(hi|nv)"

#We exit with return code = 1
exit 1

}

set game [lrange $argv 0 0]

# set time out in seconds before expect will fail reading
set timeout 5

spawn mono HiToText.exe
match_max 100000

expect ">"

send -- "-r $game"

send -- "-q"

expect eof
